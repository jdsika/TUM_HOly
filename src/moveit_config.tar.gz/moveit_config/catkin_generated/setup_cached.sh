#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH="/home/holy/HOly/holy/src/moveit_config/devel:$CMAKE_PREFIX_PATH"
export CPATH="/home/holy/HOly/holy/src/moveit_config/devel/include:$CPATH"
export LD_LIBRARY_PATH="/home/holy/HOly/holy/src/moveit_config/devel/lib:/home/holy/HOly/holy/src/moveit_config/devel/lib/i386-linux-gnu:/home/holy/HOly/holy/devel/lib/i386-linux-gnu:/opt/ros/indigo/lib/i386-linux-gnu:/home/holy/HOly/holy/devel/lib:/opt/ros/indigo/lib"
export PATH="/home/holy/HOly/holy/src/moveit_config/devel/bin:$PATH"
export PKG_CONFIG_PATH="/home/holy/HOly/holy/src/moveit_config/devel/lib/pkgconfig:/home/holy/HOly/holy/src/moveit_config/devel/lib/i386-linux-gnu/pkgconfig:/home/holy/HOly/holy/devel/lib/i386-linux-gnu/pkgconfig:/opt/ros/indigo/lib/i386-linux-gnu/pkgconfig:/home/holy/HOly/holy/devel/lib/pkgconfig:/opt/ros/indigo/lib/pkgconfig:/usr/local/lib/pkgconfig"
export PYTHONPATH="/home/holy/HOly/holy/src/moveit_config/devel/lib/python2.7/dist-packages:$PYTHONPATH"
export ROSLISP_PACKAGE_DIRECTORIES="/home/holy/HOly/holy/src/moveit_config/devel/share/common-lisp:$ROSLISP_PACKAGE_DIRECTORIES"
export ROS_PACKAGE_PATH="/home/holy/HOly/holy/src/moveit_config:$ROS_PACKAGE_PATH"
export RTT_COMPONENT_PATH="/home/holy/HOly/holy/src/moveit_config/devel/lib/orocos:$RTT_COMPONENT_PATH"