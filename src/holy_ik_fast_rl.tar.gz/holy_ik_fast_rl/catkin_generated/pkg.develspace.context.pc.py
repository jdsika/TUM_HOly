# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "".split(';') if "" != "" else []
PROJECT_CATKIN_DEPENDS = "moveit_core;pluginlib;roscpp;tf_conversions".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "".split(';') if "" != "" else []
PROJECT_NAME = "holy_ik_fast_rl"
PROJECT_SPACE_DIR = "/home/holy/HOly/holy/devel"
PROJECT_VERSION = "0.0.0"
